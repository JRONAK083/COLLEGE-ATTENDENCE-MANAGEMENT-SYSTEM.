package com.javaproject.collegeattendance;

import javax.swing.JFrame;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Dimension;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import net.miginfocom.swing.MigLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.awt.Color;

public class InputStudentAttendance {
	private JFrame frmInputStudentAttendance;
	private JTextField textField;
	private JTextField textField_2;
	public InputStudentAttendance(final String text)
	{
		frmInputStudentAttendance = new JFrame();
		frmInputStudentAttendance.getContentPane().setBackground(new Color(102, 255, 153));
		frmInputStudentAttendance.setTitle("Input Student Attendance");
		frmInputStudentAttendance.setVisible(true);
		frmInputStudentAttendance.setLocation(500,280);
		frmInputStudentAttendance.setSize(493, 394);
		
		JLabel lblStudentId = new JLabel("Student ID :");
		lblStudentId.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblStudentId.setBounds(22, 56, 99, 28);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		textField.setBounds(176, 60, 136, 20);
		textField.setColumns(10);
		textField.setText(text);
		
		JLabel lblSubject = new JLabel("Subject :");
		lblSubject.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblSubject.setBounds(22, 130, 99, 17);
		
		
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		comboBox.setBounds(176, 128, 136, 20);
		comboBox.addItem("-Select-");
		comboBox.addItem("Physics");
		comboBox.addItem("Maths");
		comboBox.addItem("Chemistry");
		comboBox.addItem("EM");
		comboBox.addItem("BEE");
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		btnNewButton.setBounds(187, 270, 105, 36);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int subject=comboBox.getSelectedIndex();
				InputStudentDatadb inp=new InputStudentDatadb(text,subject,textField_2.getText());
			}
		});
		JLabel lblNoOfLectures = new JLabel("No. of lectures:");
		lblNoOfLectures.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblNoOfLectures.setBounds(22, 184, 149, 28);
		
		textField_2 = new JTextField();
		textField_2.setBounds(176, 189, 136, 20);
		textField_2.setColumns(10);
		frmInputStudentAttendance.getContentPane().setLayout(null);
		frmInputStudentAttendance.getContentPane().add(lblStudentId);
		frmInputStudentAttendance.getContentPane().add(textField);
		frmInputStudentAttendance.getContentPane().add(lblSubject);
		frmInputStudentAttendance.getContentPane().add(comboBox);
		frmInputStudentAttendance.getContentPane().add(lblNoOfLectures);
		frmInputStudentAttendance.getContentPane().add(textField_2);
		frmInputStudentAttendance.getContentPane().add(btnNewButton);
		
	}
}
