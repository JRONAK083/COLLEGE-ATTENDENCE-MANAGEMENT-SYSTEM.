package com.javaproject.collegeattendance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class InputStudentDatadb {
	public InputStudentDatadb(String text, int subject, String No) {
		String dbName="CollegeDB";
		String driverName="com.mysql.jdbc.Driver";
					String url="jdbc:mysql://localhost:3306/";
					String dbs="";
					int number=Integer.parseInt(No);
					switch(subject)
					{
					case 1:
						dbs="Phy_Att=Phy_Att+";
						break;
					case 2:
						dbs="Math_Att=Math_Att+";
						break;
					case 3:
						dbs="Chem_Att=Chem_Att+";
						break;
					case 4:
						dbs="Em_Att=Em_Att+";
						break;
					case 5:
						dbs="Bee_Att=Bee_Att+";
						break;
					}
					try{
						Class.forName(driverName);
						Connection con=DriverManager.getConnection(url+dbName, "root", "root");
						java.sql.PreparedStatement st=con.prepareStatement("update StudentData set "+dbs+No+" where Id=?");
						st.setString(1, text);
						int a=st.executeUpdate();
							if(a!=0) {
								JOptionPane.showMessageDialog(null,"Successfully updated");	
							}
							else {
								JOptionPane.showMessageDialog(null,"invalid username or password");
							}
							
				}
					catch(Exception e)
					{
						e.printStackTrace();
					}
	}
}
