package com.javaproject.collegeattendance;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JTextField;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;

public class LoginPage {
	static private JFrame frmLogin;
	private static JTextField textField;
	private static JPasswordField passwordField;
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void initialize(final int logintype) {
		final String logintype1=Integer.toString(logintype);
		frmLogin = new JFrame();
		frmLogin.setTitle("Login");
		frmLogin.getContentPane().setBackground(new Color(255, 204, 102));
		frmLogin.setSize(540,429);
		//frmLogin.setTitle("Login Page");
		frmLogin.setLocation(500,280);
		frmLogin.setVisible(true);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblUserId = new JLabel("User ID :");
		lblUserId.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		lblUserId.setBounds(62, 108, 74, 26);
		frmLogin.getContentPane().add(lblUserId);
		
		textField = new JTextField();
		textField.setBounds(194, 112, 141, 20);
		frmLogin.getContentPane().add(textField);
		textField.setColumns(10);
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		lblPassword.setBounds(62, 176, 89, 26);
		frmLogin.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(194, 180, 141, 20);
		frmLogin.getContentPane().add(passwordField);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Segoe Print", Font.BOLD, 16));
		btnLogin.setBounds(194, 281, 89, 23);
		frmLogin.getContentPane().add(btnLogin);
		
		JLabel lblStudentLoginPage = new JLabel("STUDENT LOGIN PAGE!!!");
		lblStudentLoginPage.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblStudentLoginPage.setBounds(162, 34, 219, 14);
		frmLogin.getContentPane().add(lblStudentLoginPage);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String dbName="CollegeDB";
	String driverName="com.mysql.jdbc.Driver";
				String url="jdbc:mysql://localhost:3306/";
				
				try{
					Class.forName(driverName);
					Connection con=DriverManager.getConnection(url+dbName, "root", "root");
					java.sql.PreparedStatement st=con.prepareStatement("Select * from LoginData where Id=? and pass=? and type=?");
					st.setString(1, textField.getText());
					st.setString(2,String.valueOf(passwordField.getText()));
					st.setString(3,logintype1);
					ResultSet rs=st.executeQuery();
						if(rs.next()) {
							JOptionPane.showMessageDialog(null,"login successful");	
							MenuForward S=new MenuForward(textField.getText(),logintype);
							
						}
						else {
							JOptionPane.showMessageDialog(null,"invalid username or password");
						}
						
			}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
		}}
		);
	}
}
