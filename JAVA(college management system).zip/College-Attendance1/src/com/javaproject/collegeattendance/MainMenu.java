package com.javaproject.collegeattendance;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Button;
import javax.swing.JMenuItem;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import java.awt.Color;

public class MainMenu extends JFrame{
	private JFrame frame;

	public static void main(String[] args) { 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu window = new MainMenu();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMenu() {
		getContentPane().setBackground(new Color(255, 255, 153));
		setTitle("Menu");
		initialize();
	}

private void initialize() {
	frame = new JFrame();
	setSize(538,433);
	setLocation(500,280);
	getContentPane().setLayout(null);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setVisible(true);
	
	JButton btnStudentLogin = new JButton("Student\r\n Login");
	btnStudentLogin.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 12));
	btnStudentLogin.setBackground(new Color(255, 204, 102));
	btnStudentLogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			//frame.dispose();
			LoginPage.initialize(1);
		}
	});
	btnStudentLogin.setBounds(287, 127, 156, 138);
	getContentPane().add(btnStudentLogin);
	
	JButton btnTeacherLogin = new JButton("Teacher Login");
	btnTeacherLogin.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 12));
	btnTeacherLogin.setBackground(new Color(255, 153, 255));
	btnTeacherLogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			//frame.dispose();
			TeacherLogin.initialize();
		}
	});
	btnTeacherLogin.setBounds(35, 127, 156, 138);
	getContentPane().add(btnTeacherLogin);
	
	/*JButton btnAdminLogin = new JButton("Admin Login");
	btnAdminLogin.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 12));
	btnAdminLogin.setBackground(new Color(153, 255, 153));
	btnAdminLogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//frame.setVisible(false);
			LoginPage.initialize(3);
		}
	});
	btnAdminLogin.setBounds(368, 127, 128, 138);
	getContentPane().add(btnAdminLogin);*/
	
	JLabel lblWelcomeToAp = new JLabel("WELCOME TO AP SHAH INSTITUTE OF TECHNOLOGY");
	lblWelcomeToAp.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
	lblWelcomeToAp.setBounds(35, 35, 461, 14);
	getContentPane().add(lblWelcomeToAp);
	
}
}

