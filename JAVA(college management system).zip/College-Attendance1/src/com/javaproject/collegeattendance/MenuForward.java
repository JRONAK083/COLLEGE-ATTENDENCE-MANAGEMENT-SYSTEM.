package com.javaproject.collegeattendance;

public class MenuForward {

	public MenuForward(String text, int logintype) {
		switch(logintype)
		{
		case 1:
		{
			StudentMenu S=new StudentMenu(text);
			break;
		}
		case 2:
		{
			TeacherMenu t=new TeacherMenu(text);
			break;
		}
		}
	}

}
