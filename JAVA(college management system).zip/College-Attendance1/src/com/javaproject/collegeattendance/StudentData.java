package com.javaproject.collegeattendance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

public class StudentData {

	public ArrayList getStudentData(String text) throws Exception{
		String dbName="CollegeDB";
		String driverName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/";
			Class.forName(driverName);
			Connection con=DriverManager.getConnection(url+dbName, "root", "root");
			java.sql.PreparedStatement st=con.prepareStatement("Select * from StudentData where Id=?");
			st.setString(1, text);
			ResultSet rs=st.executeQuery();
			ArrayList result = new ArrayList();
				  if(rs.next())
				  {
					  result.add(rs.getString(1));
					  result.add(rs.getString(2));
					  result.add(rs.getString(3));
					  result.add(rs.getString(4));
					  result.add(rs.getString(5));
					  result.add(rs.getString(6));
					  result.add(rs.getString(7));
					  result.add(rs.getString(8));
					  /*database format=> ID-Name-Overall attendance-Subject 1 attendance-
					   * Subject 2 attendance-Subject 3 attendance-Subject 4 attendance-Subject 5 attendance
					   */
				  }
				  else
				  {
					  result.add("Invalid Id");
				  }	
		return result;
	}

}
