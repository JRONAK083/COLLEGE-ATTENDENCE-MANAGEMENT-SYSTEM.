package com.javaproject.collegeattendance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class StudentMenu {
	static private JFrame frame;
	public StudentMenu(String text) {
		StudentData st=new StudentData();
		try {
			ArrayList result=st.getStudentData(text);
			display(result.get(1).toString(),result.get(2).toString());
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void display(String name,String Attendance) {
		String ab=Attendance;
		int Attendance1=Integer.parseInt(ab);
		//double percentage=((Attendance1/160)*100);
		double percentage=((Attendance1*100)/160);
		//JOptionPane.showMessageDialog(null,"Hello, "+name+" Your Overall Attendance is "+Attendance+"/160 = "+percentage);
		JOptionPane.showMessageDialog(null,"Hello, "+name+" Your Overall Attendance is"+percentage+" %");
	}

}
