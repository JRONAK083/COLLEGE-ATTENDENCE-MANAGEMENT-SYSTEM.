package com.javaproject.collegeattendance;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;

public class TeacherLogin {
	static private JFrame frmTeacherLogin;
	private static JTextField textField;
	private static JPasswordField passwordField;
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void initialize() {
		frmTeacherLogin = new JFrame();
		frmTeacherLogin.getContentPane().setBackground(new Color(255, 204, 204));
		frmTeacherLogin.setVisible(true);
		frmTeacherLogin.setLocation(500,280);
		frmTeacherLogin.setSize(540,430);
		frmTeacherLogin.getContentPane().setLayout(null);
		
		JLabel lblStudentId = new JLabel("Teacher ID :");
		lblStudentId.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		lblStudentId.setBounds(50, 109, 115, 26);
		frmTeacherLogin.getContentPane().add(lblStudentId);
		
		textField = new JTextField();
		textField.setBackground(new Color(255, 255, 255));
		textField.setBounds(192, 113, 150, 20);
		frmTeacherLogin.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		lblPassword.setBounds(50, 183, 89, 26);
		frmTeacherLogin.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(192, 187, 150, 20);
		frmTeacherLogin.getContentPane().add(passwordField);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Segoe Print", Font.BOLD, 16));
		btnLogin.setBounds(205, 283, 115, 23);
		frmTeacherLogin.getContentPane().add(btnLogin);
		
		JLabel lblTeacherLoginPage = new JLabel("TEACHER LOGIN PAGE!!!");
		lblTeacherLoginPage.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblTeacherLoginPage.setBounds(158, 30, 241, 14);
		frmTeacherLogin.getContentPane().add(lblTeacherLoginPage);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String dbName="CollegeDB";
	String driverName="com.mysql.jdbc.Driver";
				String url="jdbc:mysql://localhost:3306/";
				
				try{
					Class.forName(driverName);
					Connection con=DriverManager.getConnection(url+dbName, "root", "root");
					java.sql.PreparedStatement st=con.prepareStatement("Select * from Tea_Data where Id=? and pass=?");
					
					st.setString(1, textField.getText());
					st.setString(2,String.valueOf(passwordField.getText()));
					ResultSet rs=st.executeQuery();
						if(rs.next()) {
							JOptionPane.showMessageDialog(null,"login successful");	
							MenuForward S24=new MenuForward(textField.getText(),2);
						}
						else {
							JOptionPane.showMessageDialog(null,"invalid username or password");
						}
						
			}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
		}}
		);
	}
}
