package com.javaproject.collegeattendance;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;

public class TeacherMenu {
	private JFrame frmTeacherMenu;
	private JTextField textField;
	public TeacherMenu(final String text) {
		frmTeacherMenu = new JFrame();
		frmTeacherMenu.setBackground(new Color(152, 251, 152));
		frmTeacherMenu.getContentPane().setBackground(new Color(255, 182, 193));
		frmTeacherMenu.setTitle("Teacher Menu");
		frmTeacherMenu.setVisible(true);
		frmTeacherMenu.setLocation(500, 280);
		frmTeacherMenu.setSize(540,430);
		JButton btnCheckStudentAttendance = new JButton("Check Student Attendance");
		btnCheckStudentAttendance.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		btnCheckStudentAttendance.setBounds(112, 215, 292, 33);
		btnCheckStudentAttendance.setBackground(new Color(153, 204, 255));
		btnCheckStudentAttendance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentMenu std=new StudentMenu(textField.getText());
			}
		});
		
		JButton btnInputStudentAttendance = new JButton("Input Student Attendance");
		btnInputStudentAttendance.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 14));
		btnInputStudentAttendance.setBounds(112, 309, 292, 33);
		btnInputStudentAttendance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InputStudentAttendance input=new InputStudentAttendance(textField.getText());
			}
		});
		btnInputStudentAttendance.setBackground(new Color(153, 204, 255));
		frmTeacherMenu.getContentPane().setLayout(null);
		frmTeacherMenu.getContentPane().add(btnCheckStudentAttendance);
		frmTeacherMenu.getContentPane().add(btnInputStudentAttendance);
		
		JLabel lblStudentId = new JLabel("Student ID: ");
		lblStudentId.setFont(new Font("Segoe Print", Font.BOLD | Font.ITALIC, 16));
		lblStudentId.setBounds(41, 107, 114, 14);
		frmTeacherMenu.getContentPane().add(lblStudentId);
		
		textField = new JTextField();
		textField.setForeground(new Color(0, 0, 0));
		textField.setBounds(194, 105, 149, 20);
		frmTeacherMenu.getContentPane().add(textField);
		textField.setColumns(10);
		
	}
}
